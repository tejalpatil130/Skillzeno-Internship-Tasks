"""
Python Utility Tool - Expense Calculator
A beginner-friendly console app demonstrating functions, input validation,
error handling, and clear user feedback.
"""

from decimal import Decimal, InvalidOperation
from datetime import datetime
import csv
from pathlib import Path

DATA_FILE = Path(__file__).with_name("expenses.csv")


def read_amount(prompt: str) -> Decimal:
    """Read a positive numeric amount from the user."""
    while True:
        raw = input(prompt).strip()
        try:
            amount = Decimal(raw)
            if not amount.is_finite() or amount <= 0:
                print("Please enter an amount greater than 0.")
                continue
            return amount
        except InvalidOperation:
            print("Invalid amount. Enter a number such as 125 or 125.50.")


def read_text(prompt: str) -> str:
    """Read non-empty text."""
    while True:
        value = input(prompt).strip()
        if value:
            return value
        print("This field cannot be empty. Please try again.")


def ensure_data_file() -> None:
    """Create the CSV file with a header if it does not exist."""
    if not DATA_FILE.exists():
        with DATA_FILE.open("w", newline="", encoding="utf-8") as file:
            writer = csv.writer(file)
            writer.writerow(["date", "category", "description", "amount"])


def add_expense() -> None:
    """Collect and save one expense."""
    category = read_text("Category (e.g., Food, Travel): ")
    description = read_text("Description: ")
    amount = read_amount("Amount (₹): ")
    date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    try:
        ensure_data_file()
        with DATA_FILE.open("a", newline="", encoding="utf-8") as file:
            csv.writer(file).writerow([date, category, description, str(amount)])
        print(f"\nExpense saved successfully: ₹{amount:.2f}")
    except OSError as error:
        print(f"Could not save the expense. Please check file permissions. Details: {error}")


def load_expenses() -> list:
    """Load saved expenses, handling missing or unreadable files."""
    if not DATA_FILE.exists():
        return []
    try:
        with DATA_FILE.open("r", newline="", encoding="utf-8") as file:
            return list(csv.DictReader(file))
    except (OSError, csv.Error) as error:
        print(f"Could not read expense records: {error}")
        return []


def view_expenses() -> None:
    """Display all recorded expenses."""
    expenses = load_expenses()
    if not expenses:
        print("\nNo expenses recorded yet.")
        return

    print("\n" + "-" * 72)
    print(f"{'Date':19}  {'Category':14}  {'Description':20}  {'Amount':>10}")
    print("-" * 72)
    for item in expenses:
        try:
            amount = Decimal(item["amount"])
            print(
                f"{item['date'][:19]:19}  {item['category'][:14]:14}  "
                f"{item['description'][:20]:20}  ₹{amount:>9.2f}"
            )
        except (KeyError, InvalidOperation):
            print("Warning: skipped a record with invalid data.")
    print("-" * 72)


def show_total() -> None:
    """Calculate and display the total of saved expenses."""
    expenses = load_expenses()
    total = Decimal("0")
    for item in expenses:
        try:
            total += Decimal(item["amount"])
        except (KeyError, InvalidOperation):
            continue
    print(f"\nTotal recorded expenses: ₹{total:.2f}")


def show_menu() -> None:
    print("\n" + "=" * 38)
    print("       PYTHON EXPENSE CALCULATOR")
    print("=" * 38)
    print("1. Add an expense")
    print("2. View all expenses")
    print("3. Show total expenses")
    print("4. Exit")


def main() -> None:
    """Run the application menu."""
    ensure_data_file()
    while True:
        show_menu()
        choice = input("Choose an option (1-4): ").strip()
        if choice == "1":
            add_expense()
        elif choice == "2":
            view_expenses()
        elif choice == "3":
            show_total()
        elif choice == "4":
            print("Thank you for using Python Expense Calculator. Goodbye!")
            break
        else:
            print("Invalid choice. Please enter 1, 2, 3, or 4.")


if __name__ == "__main__":
    try:
        main()
    except (KeyboardInterrupt, EOFError):
        print("\nApplication closed safely.")
