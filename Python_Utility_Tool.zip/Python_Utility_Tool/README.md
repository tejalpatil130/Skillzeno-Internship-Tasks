# Python Utility Tool — Expense Calculator

## Overview
A simple command-line expense calculator built with Python. It lets users add expenses, view saved records, and calculate total spending.

## Features
- Add expenses with category, description, and amount
- Validate blank fields and invalid/non-positive amounts
- Handle incorrect menu choices and common file errors
- Save data locally in `expenses.csv`
- Display individual records and total expenses
- Uses functions and Python's built-in `csv`, `decimal`, `datetime`, and `pathlib` modules

## Requirements
- Python 3.9 or newer
- No third-party packages required

## How to run (Windows)
1. Extract the ZIP file.
2. Open the extracted `Python_Utility_Tool` folder.
3. Click the folder address bar, type `cmd`, and press Enter.
4. Run:

```bash
python main.py
```

If `python` is not recognized, try:

```bash
py main.py
```

## Menu
1. Add an expense
2. View all expenses
3. Show total expenses
4. Exit

## Data storage
Expenses are saved to `expenses.csv` in the same folder as `main.py`. Keep this file if you want to retain your records.

## Example
```text
PYTHON EXPENSE CALCULATOR
1. Add an expense
2. View all expenses
3. Show total expenses
4. Exit
Choose an option (1-4): 1
Category (e.g., Food, Travel): Food
Description: Lunch
Amount (₹): 120
Expense saved successfully: ₹120.00
```

## Concepts demonstrated
- Functions and modular code
- Input validation
- Exception handling
- File handling with CSV
- Decimal arithmetic for money
- Clear user prompts and messages
